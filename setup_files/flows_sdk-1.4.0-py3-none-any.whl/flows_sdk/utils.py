def workflow_input(*params: str) -> str:
    assert len(params) > 0, 'At least one parameter has to be specified for workflow inputs'
    param_path = '.'.join(params)
    return f'${{workflow.input.{param_path}}}'


def triggers_output(*params: str) -> str:
    param_path = '.'.join(params)
    param_path = f'.{param_path}' if param_path else ''
    return '${triggers.output.result' + param_path + '}'


def system_setting(key: str) -> str:
    return f'${{system.settings.{key}}}'


def system_secret(key: str) -> str:
    return f'${{system.secrets.{key}}}'
