"""
This module contains types that can be useful for writing flows but are not part of the flow's
topology.

Available since v35.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum, auto
from typing import Iterable, List


@dataclass(frozen=True)
class StoreBlobRequest(object):
    """
    Encapsulates the request parameters for storing a blob.
    """

    name: str
    """Name that will be associated with the blob."""
    content: bytes
    """Blob content in bytes."""


@dataclass(frozen=True)
class StoreBlobResponse(object):
    """
    The result of storing a blob. Contains data that can be used to retrieve the blob.
    """

    uuid: str
    """Unique identifier of the created blob."""
    name: str
    """Name associated with the blob."""


@dataclass(frozen=True)
class Blob(object):
    """
    The result of fetching a blob from the object store.
    """

    content: bytes
    """The content of the blob in bytes."""


@dataclass(frozen=True)
class HsTask:
    """
    A task in the flow engine runtime - contains task and flow metadata.

    Available since v35.
    """

    task_id: str
    """Unique identifier of the task withing the system"""
    flow_run_id: str
    """Unique identifier of the flow run withing the system"""
    correlation_id: str
    """A string that gets passed from parent to child flow runs and can be used to
    identify flow runs that belong to the same execution graph"""
    task_name: str
    """The name of the block that runs the task, e.g. PYTHON_CODE"""
    reference_name: str
    """The unique identifier of the task in the flow definition"""


class HsBlockInstance(ABC):
    """
    Provides an interface for the base block APIs in code blocks.

    Available since v35.
    """

    class LogLevel(Enum):
        DEBUG = auto()
        INFO = auto()
        WARN = auto()
        ERROR = auto()

    @abstractmethod
    def store_blob(self, blob: StoreBlobRequest) -> StoreBlobResponse:
        """
        Stores a blob in the object store. For more information see store_blobs.
        """
        pass

    @abstractmethod
    def store_blobs(self, blobs: Iterable[StoreBlobRequest]) -> List[StoreBlobResponse]:
        """
        Stores a list of blobs in the object store. The blobs will be associated with the
        flow run where this code gets executed. When this flow run is deleted the blobs will be
        deleted as well.
        """
        pass

    @abstractmethod
    def fetch_blob(self, blob_reference: str) -> Blob:
        """
        Retrieves the contents for the provided blob reference string.
        """
        pass

    @abstractmethod
    def log(self, msg: str, level: LogLevel = LogLevel.INFO) -> None:
        """
        Logs a message at the given log level both to the standard out/err stream and to the
        flow execution context, making it available in the `Logs` tab of the View Flow Execution UI.
        Prepends meta information that makes the logs easier to trace (e.g. by correlation id)
        """
        pass
