import json
import sys
import uuid
from typing import Any

from flows_sdk.flows import Flow


def export_flow(flow: Flow, filename: str = None, location: str = '.') -> None:
    class JSONEncoder(json.JSONEncoder):
        """
        JSONEncoder subclass that encodes UUIDs as strings.
        """

        def default(self, o: Any) -> Any:
            if isinstance(o, uuid.UUID):
                return str(o)
            else:
                return super().default(o)

    def _generate_json(target_flow: Flow) -> str:
        return json.dumps(target_flow.render(), indent=2, cls=JSONEncoder) + '\n'

    if filename:
        with open(file=f'{location}/{filename}.json', mode='w') as f:
            f.write(_generate_json(flow))
    else:
        sys.stdout.write(_generate_json(flow))
